<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'qi', 'geng', 'che', 'jia', 'hua', 'chuan', 'ju', 'gui', 'gui', 'qi', 'jin', 'la', 'nai', 'lan', 'lai', 'luo',
  0x10 => 'luo', 'luo', 'luo', 'luo', 'le', 'luo', 'lao', 'luo', 'luo', 'lao', 'luo', 'luan', 'luan', 'lan', 'lan', 'lan',
  0x20 => 'luan', 'lan', 'lan', 'lan', 'lan', 'la', 'la', 'la', 'lang', 'lang', 'lang', 'lang', 'lang', 'lai', 'leng', 'lao',
  0x30 => 'lu', 'lu', 'lu', 'lu', 'lao', 'lu', 'lu', 'lu', 'lu', 'lu', 'lu', 'lu', 'lu', 'lu', 'lu', 'lu',
  0x40 => 'lu', 'lun', 'long', 'nong', 'long', 'long', 'lao', 'lei', 'lu', 'lei', 'lei', 'lu', 'lou', 'lei', 'lou', 'lei',
  0x50 => 'lu', 'lou', 'lei', 'le', 'lin', 'ling', 'leng', 'ling', 'ling', 'ling', 'du', 'na', 'le', 'nuo', 'dan', 'ning',
  0x60 => 'nu', 'lu', 'yi', 'bei', 'pan', 'bian', 'fu', 'bu', 'mi', 'shu', 'suo', 'can', 'sai', 'sheng', 'ye', 'shuo',
  0x70 => 'sha', 'chen', 'chen', 'shi', 'ruo', 'e', 'e', 'liang', 'liang', 'liang', 'liang', 'liang', 'liang', 'liang', 'liang', 'li',
  0x80 => 'lu', 'nu', 'lu', 'lu', 'lu', 'li', 'lu', 'li', 'li', 'li', 'li', 'li', 'li', 'li', 'nian', 'lian',
  0x90 => 'lian', 'nian', 'lian', 'lian', 'lian', 'nian', 'lian', 'lian', 'nian', 'lian', 'lian', 'lian', 'lie', 'lie', 'yan', 'lie',
  0xA0 => 'lie', 'shuo', 'lian', 'nian', 'nian', 'lian', 'lian', 'lie', 'ling', 'ling', 'ning', 'ling', 'lian', 'ling', 'ying', 'ling',
  0xB0 => 'ling', 'ling', 'ling', 'ling', 'ling', 'li', 'li', 'li', 'li', 'e', 'le', 'liao', 'liao', 'niao', 'liao', 'le',
  0xC0 => 'liao', 'liao', 'liao', 'liao', 'long', 'yun', 'ruan', 'liu', 'chou', 'liu', 'liu', 'liu', 'liu', 'liu', 'liu', 'niu',
  0xD0 => 'lei', 'liu', 'lu', 'lu', 'lun', 'lun', 'lun', 'lun', 'lu', 'li', 'li', 'lu', 'long', 'li', 'li', 'lu',
  0xE0 => 'yi', 'li', 'li', 'ni', 'li', 'li', 'li', 'li', 'li', 'li', 'li', 'ni', 'ni', 'lin', 'lin', 'lin',
  0xF0 => 'lin', 'lin', 'lin', 'lin', 'lin', 'lin', 'lin', 'li', 'li', 'li', 'zhuang', 'zhi', 'shi', 'shen', 'cha', 'ci',
];
